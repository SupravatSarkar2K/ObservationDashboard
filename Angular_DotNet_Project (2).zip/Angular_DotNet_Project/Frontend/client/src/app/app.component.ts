import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Construction Monitoring';
  activeTab = 'summary'; // Default tab

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }
}
