import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Observation, SamplingData } from '../models/observation.model';

@Injectable({
  providedIn: 'root'
})
export class ObservationService {
  private dataUrl = 'assets/data/observations.json'; // Path to the JSON file
  private observationData: Observation | null = null;

  constructor(private http: HttpClient) { }

  // Get all observation data
  getObservation(): Observable<Observation> {
    if (this.observationData) {
      return of(this.observationData);
    }
    
    return this.http.get<Observation>(this.dataUrl).pipe(
      tap(data => this.observationData = data),
      catchError(this.handleError)
    );
  }

  // Get all sampling data
  getAllSamplingData(): Observable<SamplingData[]> {
    return this.getObservation().pipe(
      map(observation => observation.Datas)
    );
  }

  // Get specific sampling data by time
  getSamplingDataByTime(time: string): Observable<SamplingData | undefined> {
    return this.getAllSamplingData().pipe(
      map(samplingDataArray => 
        samplingDataArray.find(data => data.SamplingTime === time)
      )
    );
  }

  // Update sampling data
  updateSamplingData(updatedData: SamplingData): Observable<Observation> {
    if (!this.observationData) {
      return throwError(() => new Error('No observation data loaded'));
    }

    // Find the index of the sampling data to update
    const index = this.observationData.Datas.findIndex(
      data => data.SamplingTime === updatedData.SamplingTime
    );

    if (index === -1) {
      return throwError(() => new Error('Sampling data not found'));
    }

    // Update the sampling data
    this.observationData.Datas[index] = updatedData;

    // Save the updated data back to the file (or API)
    return this.http.put<Observation>(this.dataUrl, this.observationData).pipe(
      tap(data => this.observationData = data),
      catchError(this.handleError)
    );
  }

  private handleError(error: any) {
    console.error('An error occurred:', error);
    return throwError(() => new Error('Something went wrong. Please try again later.'));
  }
}

// services/mock-api.interceptor.ts
import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse
} from '@angular/common/http';
import { delay, mergeMap } from 'rxjs/operators';

@Injectable()
export class MockApiInterceptor implements HttpInterceptor {
  private observationData: Observation | null = null;

  constructor() { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    // Only intercept requests to our "API" endpoint
    if (request.url.includes('assets/data/observations.json')) {
      // Simulate API delay
      return of(null).pipe(
        delay(300),
        mergeMap(() => {
          if (request.method === 'GET') {
            return this.handleGetRequest();
          } else if (request.method === 'PUT') {
            return this.handlePutRequest(request);
          } else {
            // Pass through any other requests
            return next.handle(request);
          }
        })
      );
    }
    
    // Pass through any other requests
    return next.handle(request);
  }

  private handleGetRequest(): Observable<HttpEvent<Observation>> {
    // If we haven't loaded the data yet, fetch it from the asset
    if (!this.observationData) {
      // This will only be executed once to load the initial data
      return fetch('assets/data/observations.json')
        .then(response => response.json())
        .then(data => {
          this.observationData = data;
          return new HttpResponse<Observation>({
            status: 200,
            body: this.observationData
          });
        });
    }
    
    // Return the cached data
    return of(new HttpResponse<Observation>({
      status: 200,
      body: this.observationData
    }));
  }

  private handlePutRequest(request: HttpRequest<unknown>): Observable<HttpEvent<Observation>> {
    // Update the stored data
    this.observationData = request.body as Observation;
    
    // Return success response
    return of(new HttpResponse<Observation>({
      status: 200,
      body: this.observationData
    }));
  }
}