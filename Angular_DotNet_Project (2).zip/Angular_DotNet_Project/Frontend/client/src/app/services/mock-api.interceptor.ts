
import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay, mergeMap } from 'rxjs/operators';
import { Observation } from '../models/observation.model';

@Injectable()
export class MockApiInterceptor implements HttpInterceptor {
  private observationData: Observation | null = null;

  constructor() { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    // Only intercept requests to our "API" endpoint
    if (request.url.includes('assets/data/observations.json')) {
      // Simulate API delay
      return of(null).pipe(
        delay(300),
        mergeMap(() => {
          if (request.method === 'GET') {
            return this.handleGetRequest();
          } else if (request.method === 'PUT') {
            return this.handlePutRequest(request);
          } else {
            // Pass through any other requests
            return next.handle(request);
          }
        })
      );
    }
    
    // Pass through any other requests
    return next.handle(request);
  }

  private handleGetRequest(): Observable<HttpEvent<Observation>> {
    // If we haven't loaded the data yet, fetch it from the asset
    // if (!this.observationData) {
    //   // This will only be executed once to load the initial data
    //   return fetch('assets/data/observations.json')
    //     .then(response => response.json())
    //     .then(data => {
    //       this.observationData = data;
    //       return new HttpResponse<Observation>({
    //         status: 200,
    //         body: this.observationData
    //       });
    //     });
    // }
    
    // Return the cached data
    return of(new HttpResponse<Observation>({
      status: 200,
      body: this.observationData
    }));
  }

  private handlePutRequest(request: HttpRequest<unknown>): Observable<HttpEvent<Observation>> {
    // Update the stored data
    this.observationData = request.body as Observation;
    
    // Return success response
    return of(new HttpResponse<Observation>({
      status: 200,
      body: this.observationData
    }));
  }
}