import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Property, SamplingData } from '../../../models/observation.model';
import { ObservationService } from '../../services/observation.service';

@Component({
  selector: 'app-detailed-view',
  templateUrl: './detailed-view.component.html',
  styleUrls: ['./detailed-view.component.scss']
})
export class DetailedViewComponent implements OnInit {
  samplingTimes: string[] = [];
  selectedSamplingTime: string | null = null;
  currentSamplingData: SamplingData | null = null;
  detailForm: FormGroup | null = null;
  
  constructor(
    private observationService: ObservationService,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.loadSamplingTimes();
  }

  loadSamplingTimes(): void {
    this.observationService.getAllSamplingData().subscribe({
      next: (samplingDataArray) => {
        this.samplingTimes = samplingDataArray.map(data => {
          const date = new Date(data.SamplingTime);
          return {
            original: data.SamplingTime,
            formatted: formatDate(date, 'medium', 'en-US')
          };
        }).map(item => item.original);
        
        if (this.samplingTimes.length > 0) {
          this.selectSamplingTime(this.samplingTimes[0]);
        }
      },
      error: (err) => console.error('Error loading sampling times:', err)
    });
  }

  selectSamplingTime(time: string): void {
    this.selectedSamplingTime = time;
    this.loadSamplingDetails(time);
  }

  loadSamplingDetails(time: string): void {
    this.observationService.getSamplingDataByTime(time).subscribe({
      next: (samplingData) => {
        if (samplingData) {
          this.currentSamplingData = samplingData;
          this.createDynamicForm(samplingData.Properties);
        }
      },
      error: (err) => console.error('Error loading sampling details:', err)
    });
  }

  createDynamicForm(properties: Property[]): void {
    const formGroup = this.fb.group({});
    
    properties.forEach(prop => {
      // Create form controls based on property type
      let validators = [];
      
      if (prop.Label === 'Project Name') {
        validators.push(Validators.required);
      }
      
      if (typeof prop.Value === 'number' && prop.Label === 'Construction Count') {
        validators.push(Validators.min(0));
      }
      
      formGroup.addControl(
        this.getControlName(prop.Label),
        new FormControl(prop.Value, validators)
      );
    });
    
    this.detailForm = formGroup;
  }

  getControlName(label: string): string {
    return label.toLowerCase().replace(/\s+/g, '');
  }

  getFormattedSamplingTime(time: string): string {
    return formatDate(new Date(time), 'medium', 'en-US');
  }

  getControlType(controlName: string, value: any): string {
    if (typeof value === 'boolean') {
      return 'checkbox';
    } else if (typeof value === 'number') {
      return 'number';
    } else {
      return 'text';
    }
  }

  onSubmit(): void {
    if (!this.detailForm || !this.currentSamplingData || !this.selectedSamplingTime) {
      return;
    }
    
    if (this.detailForm.valid) {
      // Create updated Properties array from form values
      const updatedProperties: Property[] = this.currentSamplingData.Properties.map(prop => {
        const controlName = this.getControlName(prop.Label);
        const updatedValue = this.detailForm?.get(controlName)?.value;
        
        return {
          Label: prop.Label,
          Value: updatedValue
        };
      });
      
      // Create updated SamplingData
      const updatedSamplingData: SamplingData = {
        SamplingTime: this.selectedSamplingTime,
        Properties: updatedProperties
      };
      
      // Save the updated data
      this.observationService.updateSamplingData(updatedSamplingData).subscribe({
        next: () => {
          alert('Data updated successfully!');
        },
        error: (err) => {
          console.error('Error updating data:', err);
          alert('Error updating data. Please try again.');
        }
      });
    }
  }
}
