import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ObservationSummary, SamplingData } from '../../../models/observation.model';
import { ObservationService } from '../../services/observation.service';

@Component({
  selector: 'app-summary-view',
  templateUrl: './summary-view.component.html',
  styleUrls: ['./summary-view.component.scss']
})
export class SummaryViewComponent implements OnInit {
  summaries: ObservationSummary[] = [];
  displayedColumns: string[] = ['samplingTime', 'projectName', 'constructionCount', 'isConstructionCompleted', 'roadLength'];
  
  constructor(private observationService: ObservationService) { }

  ngOnInit(): void {
    this.loadSummaryData();
  }

  loadSummaryData(): void {
    this.observationService.getAllSamplingData().subscribe({
      next: (samplingDataArray) => {
        this.summaries = this.transformToSummaries(samplingDataArray);
      },
      error: (err) => console.error('Error loading sampling data:', err)
    });
  }

  private transformToSummaries(samplingDataArray: SamplingData[]): ObservationSummary[] {
    return samplingDataArray.map(data => {
      const summary: ObservationSummary = {
        samplingTime: formatDate(new Date(data.SamplingTime), 'medium', 'en-US')
      };
      
      // Extract property values by their labels
      data.Properties.forEach(prop => {
        switch (prop.Label) {
          case 'Project Name':
            summary.projectName = prop.Value;
            break;
          case 'Construction Count':
            summary.constructionCount = prop.Value;
            break;
          case 'Is Construction Completed':
            summary.isConstructionCompleted = prop.Value;
            break;
          case 'Length of the road':
            summary.roadLength = prop.Value;
            break;
          default:
            // For any other properties, use the label as key
            const key = prop.Label.toLowerCase().replace(/\s+/g, '');
            summary[key] = prop.Value;
        }
      });
      
      return summary;
    });
  }
}
