import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailedViewComponent } from './components/detailed-view/detailed-view.component';
import { SummaryViewComponent } from './components/summary-view/summary-view.component';

const routes: Routes = [
  { path: 'summary', component: SummaryViewComponent },
  { path: 'detailed', component: DetailedViewComponent },
  { path: '', redirectTo: '/summary', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
