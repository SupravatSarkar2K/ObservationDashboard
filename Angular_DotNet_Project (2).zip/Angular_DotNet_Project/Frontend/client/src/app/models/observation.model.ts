export interface Property {
  Value: any;
  Label: string;
}

export interface SamplingData {
  SamplingTime: string;
  Properties: Property[];
}

export interface Observation {
  Id: number;
  Name: string;
  Datas: SamplingData[];
}

// For the summary view, we'll create a flattened representation
export interface ObservationSummary {
  samplingTime: string;
  projectName: string;
  constructionCount?: number;
  isConstructionCompleted?: boolean;
  roadLength?: number;
  [key: string]: any; // For dynamic property access
}
