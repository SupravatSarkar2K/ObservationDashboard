
using System.Collections.Generic;

namespace YourProject.Models
{
    public class Observation
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<DataItem> Datas { get; set; }
    }

    public class DataItem
    {
        public string SamplingTime { get; set; }
        public List<Property> Properties { get; set; }
    }

    public class Property
    {
        public object Value { get; set; }
        public string Label { get; set; }
    }
}
